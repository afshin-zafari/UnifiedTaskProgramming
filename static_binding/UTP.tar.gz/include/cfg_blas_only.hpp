#ifndef CFG_BLAS_ONLY_HPP
#define CFG_BLAS_ONLY_HPP

#include "utp.hpp"
#include "sch_blas.hpp"

void test_BLAS_ONLY();


#endif // CFG_BLAS_ONLY_HPP
