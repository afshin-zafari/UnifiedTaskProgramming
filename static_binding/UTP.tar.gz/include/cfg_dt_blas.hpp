#ifndef CFG_DT_BLAS_HPP
#define CFG_DT_BLAS_HPP

#include "dispatcher.hpp"
#include "sch_blas.hpp"
#include "sch_ductteip.hpp"

void test_DT_BLAS();

#endif // CFG_DT_BLAS_HPP
