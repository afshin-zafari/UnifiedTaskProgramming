#ifndef CFG_CU_BLAS_ONLY_HPP
#define CFG_CU_BLAS_ONLY_HPP

#include "dispatcher.hpp"
#include "sch_cu_blas.hpp"

void test_cuBLAS_ONLY();


#endif // CFG_CU_BLAS_ONLY_HPP

