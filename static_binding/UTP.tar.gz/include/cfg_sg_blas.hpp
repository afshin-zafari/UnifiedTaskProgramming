#ifndef CFG_SG_BLAS_HPP
#define CFG_SG_BLAS_HPP

#include "dispatcher.hpp"
#include "sch_blas.hpp"
#include "sch_superglue.hpp"

void test_SG_BLAS();
namespace utp{

}

#endif // CFG_SG_BLAS_HPP
