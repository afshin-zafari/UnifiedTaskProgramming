#ifndef CFG_DT_SG_BLAS_HPP
#define CFG_DT_SG_BLAS_HPP

#include "dispatcher.hpp"
#include "sch_blas.hpp"
#include "sch_ductteip.hpp"
#include "sch_superglue.hpp"
#include "sch_starpu.hpp"

void test_DT_FORK_SG_SPU();

#endif // CFG_DT_SG_BLAS_HPP


