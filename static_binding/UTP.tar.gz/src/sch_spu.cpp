#include "sch_starpu.hpp"
namespace utp{
    SPU _spu;
}

