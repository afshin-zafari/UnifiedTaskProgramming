#include "utp_basic.hpp"

namespace utp {
    void packArgs(Args *){}
    void packAxs(Axs &){}
    void utp_initialize(int argc , char *argv[]){}
    void utp_finalize(){}
}
