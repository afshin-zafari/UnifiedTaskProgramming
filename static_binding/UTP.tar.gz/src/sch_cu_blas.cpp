#include "sch_cu_blas.hpp"
namespace utp{
    UserProgram prog;
    cuBLAS _cublas;
}

